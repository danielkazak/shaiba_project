'use strict';

/**
 * @ngdoc function
 * @name shaibaApp.controller:MobileCtrl
 * @description
 * # MobileCtrl
 * Controller of the shaibaApp
 */
angular.module('shaibaApp')
  .controller('MobileCtrl', function ($scope) {

  });
